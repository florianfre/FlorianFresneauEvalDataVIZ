function twoSum(array, target) {
    // write the body of the function
}